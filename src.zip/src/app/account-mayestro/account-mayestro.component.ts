import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-account-mayestro",
  templateUrl: "./account-mayestro.component.html",
  styleUrls: ["./account-mayestro.component.css"]
})

/**
 * main lay out of signup and login pages
 */
export class AccountMayestroComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
