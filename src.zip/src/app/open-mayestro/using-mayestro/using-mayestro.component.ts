import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-using-mayestro',
  templateUrl: './using-mayestro.component.html',
  styleUrls: ['./using-mayestro.component.css']
})
export class UsingMayestroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
