import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar-help',
  templateUrl: './sidebar-help.component.html',
  styleUrls: ['./sidebar-help.component.css']
})
export class SidebarHelpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
