import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-account-help',
  templateUrl: './edit-account-help.component.html',
  styleUrls: ['./edit-account-help.component.css']
})
export class EditAccountHelpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
