import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notification-help',
  templateUrl: './notification-help.component.html',
  styleUrls: ['./notification-help.component.css']
})
export class NotificationHelpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
