import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-help',
  templateUrl: './account-help.component.html',
  styleUrls: ['./account-help.component.css']
})
export class AccountHelpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
