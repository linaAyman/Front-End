import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-help',
  templateUrl: './login-help.component.html',
  styleUrls: ['./login-help.component.css']
})
export class LoginHelpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
