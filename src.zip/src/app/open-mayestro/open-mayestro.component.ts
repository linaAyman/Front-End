import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-open-mayestro',
  templateUrl: './open-mayestro.component.html',
  styleUrls: ['./open-mayestro.component.css']
})
export class OpenMayestroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
