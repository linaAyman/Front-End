import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mayestro',
  templateUrl: './mayestro.component.html',
  styleUrls: ['./mayestro.component.css']
})
export class MayestroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
