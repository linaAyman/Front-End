export class IPlaylist{
    name: string;
    ID: string;
    description: string;
    imgUrl: string
}