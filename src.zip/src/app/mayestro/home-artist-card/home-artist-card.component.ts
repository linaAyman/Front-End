import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-artist-card',
  templateUrl: './home-artist-card.component.html',
  styleUrls: ['./home-artist-card.component.css']
})
export class HomeArtistCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
