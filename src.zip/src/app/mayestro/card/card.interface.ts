
/**
 * Card Interface 
 */
export class ICard{
    name: string;
    description: string;
    imgUrl: string;
    ID: string;
    type:string;

}